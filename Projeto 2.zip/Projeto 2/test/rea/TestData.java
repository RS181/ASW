package rea;

import java.util.*;
import java.util.function.Function;

public class TestData {

    /**
     *
     */
    protected static final String NAMES[] = {"A random name", "Another random name", "Yet another random name"};

    /**
     *
     */
    protected static final String NAME = NAMES[0];

    /**
     * array of string of pathnames
     */
    protected static final String PATHNAMES[] = {"images/some_image.png", "images/another_image.png", "images/yet_another_image.png"};

    /**
     * first in array of string of pathnames
     */
    protected static final String PATHNAME = PATHNAMES[0];
    /**
     * background image path string
     */
    protected static final String BACKGROUND_IMAGE = "images/background.png";

    /**
     * width of scene
     */
    protected static final int WIDTH = 800;

    /**
     * height of scene
     */
    protected static final int HEIGHT = 600;

    /**
     * array of descriptions string for tests
     */
    protected static final String DESCRITIONS[] = {"A random description", "Another random description", "Yet another random description"};

    /**
     * first in array of descriptions strings for tests
     */
    protected static final String DESCRITION = DESCRITIONS[0];

    /**
     * message description string
     */
    protected static final String MESSAGE = "A random message";

    protected static final int X = 110;
    protected static final int Y = 220;

    protected static final int NEW_X = 330;
    protected static final int NEW_Y = 440;





    public class MockPool<T> extends ArrayList<T> {
        /**
         * counter
         */
        final int COUNT = 3;

        /**
         * Mock Pool constructor
         * @param create function to create
         */
        public MockPool(Function<Integer, T> create) {
            init(create, COUNT);
        }

        /**
         * Mock pool constructor
         * @param create function to create
         * @param count size
         */
        public MockPool(Function<Integer, T> create, int count) {
            init(create, count);
        }

        void init(Function<Integer, T> create, int count){
            for (int i = 0; i < count; i++) {
                add(create.apply(i));
            }
        }

        /**
         * A view of this list in reverse order.
         * This method should be in List on Java 21 ...
         * @return A view of this list in reverse order.
         */
        public List<T> reversed() {
            List<T> reversed = new ArrayList<>(this);
            Collections.reverse(reversed);
            return reversed;
        }

        /**
         * A view of this list as a Set.
         * @return set
         */
        public Set<T> asSet() {
            return new HashSet<>(this);
        }
    }

}
