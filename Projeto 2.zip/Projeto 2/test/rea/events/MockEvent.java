package rea.events;

/**
 * A sample event type for testing.
 */
public class MockEvent implements UpdateEvent { }
