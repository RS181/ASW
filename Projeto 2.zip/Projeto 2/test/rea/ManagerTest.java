package rea;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import rea.gameplay.GameplayFactory;
import rea.gameplay.MockGameplayFactory;
import rea.gaming.GameInstance;

import rea.components.Character;
import rea.gameplay.games.*;

import java.util.Date;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test for {@link Manager}
 * @author Carla Henriques <code>up202201926@edu.fc.up.pt</code>
 * @author Rui Santos <code>up202109728@edu.fc.up.pt</code>
 */
class ManagerTest {

    MockGameplayFactory gameplayFactory = new MockGameplayFactory();
    GameInstance gameInstance = null;

    Character c = new Character("character 1", CartoonAvatar.BUNNY);

    public static final String REA_GAMES = "rea.gameplay";
    GameplayFactory defaultGameplayFactory;
    static Manager pool;
    @BeforeAll
    static void setUpClass() throws ReaException {
        try{
            pool = Manager.getInstance();

        }
        catch (Exception e){
            throw new ReaException(e.getMessage());
        }
    }


    @BeforeEach
    void setUp()  throws ReaException {
        try{
            Manager.reset();

            defaultGameplayFactory = new GameplayFactory();
        }
        catch (Exception e){
            throw new ReaException(e.getMessage());
        }
    }
    @Test
    void getInstance() throws ReaException {
        try {
            Manager instance = Manager.getInstance();
            assertNotNull(instance, "instance should not be null");
        }
        catch (ReaException e){
            throw new ReaException("Manager instance is null", e);
        }
    }

    /**
     * There is a default gameplay factory
     */
    @Test
    void getGameplayFactory() {
        pool.setGameplayFactory(gameplayFactory);

        assertNotNull(pool.getGameplayFactory() , "gameplay factory should not be null");

        assertEquals(pool.getGameplayFactory(), gameplayFactory, "gameplay should be the same!");
    }

    /**
     * Gameplay factory can be changed
     */
    @Test
    void setGameplayFactory() {
        assertNull(pool.getGameplayFactory() , "gameplay factory should be null");

        // set to null
        pool.setGameplayFactory(null);
        assertNull(pool.getGameplayFactory(),"gameplay factory should be null");

        // set to not null
        pool.setGameplayFactory(gameplayFactory);
        assertNotNull(pool.getGameplayFactory(),"gameplay factory should not be null");

        assertEquals(pool.getGameplayFactory(), gameplayFactory, "gameplay should be the same!");
    }

    /**
     * Check available game names in mock gameplay factory
     */
    @Test
    void getAvailableGames_mock_gameplay_factory() {
        Set<String> availableGames =  gameplayFactory.getAvailableGameplays();
        //Set<String> availableGames =  pool.getGameplayFactory().getAvailableGameplays();
        assertTrue(availableGames.contains("Mock gameplay"), "Does not have ' Mock gameplay '");
    }


    /**
     * Check availble game names in default gameplay factory,
     * that should include Easter Egg race and Treasure Hunt
     */
    @Test
    void getAvailableGames_default_gameplay_factory() {
        pool.setGameplayFactory(defaultGameplayFactory);

        Set<String> availableGames = pool.getAvailableGames();

        assertAll(
                () -> assertTrue(availableGames.contains("Easter Egg Race"), "Does not have 'Easter Egg Race'"),
                () -> assertTrue(availableGames.contains("Treasure Hunt"), "Does not have 'Treasure Hunt'")
        );
    }


    /**
     * Create a game instance and it is available
     */
    @Test
    void createGameInstance() {
        pool.setGameplayFactory(defaultGameplayFactory);

        GameInstance gameInstance = pool.createGameInstance("Easter Egg Race");

        assertNotNull(gameInstance, "Game instance should not be null");

        assertTrue(pool.getGameInstances().contains(gameInstance), "Created game instance is not available!");
    }


    /**
     * Delete a game instance and it is not available anymore.
     * An event notifying this should be broadcasted.
     */
    @Test
    void deleteGameInstance() {
        pool.setGameplayFactory(defaultGameplayFactory);

        GameInstance gameInstance = pool.createGameInstance("Easter Egg Race");

        pool.deleteGameInstance(gameInstance);

        assertFalse(pool.getGameInstances().contains(gameInstance), "Deleted game instance is still available");
    }


    /**
     * Get game instances about to start
     */
    @Test
    void getGamesInstancesAboutToStart() {
        List<GameInstance> gamesAboutToStart;

        pool.setGameplayFactory(defaultGameplayFactory);

        gamesAboutToStart = pool.getGamesInstancesAboutToStart();
        assertEquals(0, gamesAboutToStart.size(), "Games about to start should be 0");
        assertTrue(gamesAboutToStart.isEmpty(), "Game about to start should be empty");

        GameInstance easterEggRace = pool.createGameInstance("Easter Egg Race");
        GameInstance treasureHunt = pool.createGameInstance("Treasure Hunt");

        // adds character, and it's enough for game to be about to start
        easterEggRace.addPlayer(c);
        gamesAboutToStart = pool.getGamesInstancesAboutToStart();

        assertEquals(1, gamesAboutToStart.size(), "Games about to start should be 1");
        assertTrue(gamesAboutToStart.contains(easterEggRace),
                "Game about to start should be 'easterEggRace'");

        // adds character, and it's enough for game to be about to start
        treasureHunt.addPlayer(c);
        gamesAboutToStart = pool.getGamesInstancesAboutToStart();

        assertEquals(2, gamesAboutToStart.size(), "Gamess about to start should be 2");
        assertTrue(gamesAboutToStart.contains(easterEggRace) && gamesAboutToStart.contains(treasureHunt),
                "Game about to start should be 'easterEggRace' and 'treasureHunt'.");

    }


    /**
     * By default, the time to keep a game after it ends is 5 minutes
     */
    @Test
    void getKeepAfterEnd() {
        assertNotNull(Manager.getKeepAfterEnd(),"Manager instance should not be null");

        // ADD RESET

        long gameTimeAfterEnd = Manager.getKeepAfterEnd();
        long defaultTime = pool.KEEP_AFTER_END;

        assertEquals(defaultTime, gameTimeAfterEnd, "Default time to keep a game after it ends should be 5 minutes");
    }

    @ParameterizedTest
    @ValueSource(longs = {0, 1, 2, 3, 4, 5, 10, 100, 1000})
    void setKeepAfterEnd(long keepAfterEnd) {
        assertNotNull(Manager.getKeepAfterEnd(),"Manager instance should not be null");

        Manager.setKeepAfterEnd(keepAfterEnd);

        assertEquals(keepAfterEnd, Manager.getKeepAfterEnd(),
                "keep after end should have value equal to : " + keepAfterEnd);
    }

    /**
     * Check if the game instances are recycled.
     * Create a game instance, start it, end it and check if it is removed from the pool
     * after the set delay
     * @throws InterruptedException might happen on sleep
     */
    @ParameterizedTest
    @ValueSource(longs = {0, 1, 2, 3, 4, 5, 10, 100}) // Valores originais do teste
    void recycleGameInstances(long delay) throws InterruptedException {

        pool.setGameplayFactory(defaultGameplayFactory);

        // Set delay KeepAfterEnd lower just for this test.
        pool.setKeepAfterEnd(10);
        long keepAfterEnd = pool.getKeepAfterEnd();

        // 1. Create a game instance
        GameInstance gameInstance = pool.createGameInstance("Easter Egg Race");

        // 2. Start game
        gameInstance.addPlayer(c);
        gameInstance.startPlayingGame();

        Date startedPlaying = gameInstance.getPlayingSince();

        // 4. End the game instance
        Date endedPlaying = new Date();
        gameInstance.endPlayingGame();

        try {

            // Sleep to simulate the game duration
             Thread.currentThread().sleep(delay);

            Date afterDelay = new Date();

            pool.recycleGameInstances();

            List<GameInstance> gameInstances = pool.getGameInstances();

            //System.out.println("Delay: " + afterDelay.getTime() + ", startTime: " + startedPlaying.getTime() + ", endTime: " + endedPlaying.getTime());

            // 5. Check if the game instance is removed from the pool after the delay
            if (delay >= keepAfterEnd) {
                //System.out.println("Remove: delayTotal " + delay + ", keepAfterEnd " + keepAfterEnd);
                assertFalse(gameInstances.contains(gameInstance), "Game instance should not exists after " + delay + "minutes delay");
            }
            else {
                //System.out.println("Not remove: delayTotal " + delay + ", keepAfterEnd " + keepAfterEnd);
                assertTrue(gameInstances.contains(gameInstance), "Game instance should not have been removed after " + delay + "minutes delay");
            }
        }
        catch (InterruptedException e){
            throw new InterruptedException("recycleGameInstances: error happened on sleep.");
        }
    }

}